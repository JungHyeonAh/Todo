from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import auth
# Create your views here.

# 회원 가입
def signup(request):
    if request.method == "GET":
        return render(request, 'signup.html')
    # signup 으로 POST 요청이 왔을 때, 새로운 유저를 만드는 절차를 밟는다.
    elif request.method == 'POST':
        context = {}
        username = request.POST['username']
        rs = User.objects.filter(username=request.POST['username']).exists() #아이디 중복 체크 
        
        # password와 confirm에 입력된 값이 같다면
        if request.POST['password'] == request.POST['confirm'] != '' and rs is True  and username != '' and request.POST['Email'] != '':
            context['message'] = "사용자 이름: " + username + "가 중복됩니다."
            # context['message'] = "Username:  [" + username + "]  is unavailable."
            # return render(request, 'signup.html', context)
            return render(request, 'signup.html', {'error': "사용자 이름: " + username + "가 중복됩니다."})
                
        elif request.POST['password'] == request.POST['confirm'] != '' and rs is False and username != '' and request.POST['Email'] != '':
            # user 객체를 새로 생성
            user = User.objects.create_user(username=request.POST['username'], password=request.POST['password'], email=request.POST['Email'])
            # 로그인 한다
            auth.login(request, user)
            return redirect('/')
            
        # password와 confirm이 다르면
        elif request.POST['password'] != request.POST['confirm'] and request.POST['password'] != '' and request.POST['confirm'] != '': 
            context['message'] = "비밀번호가 틀립니다."
            # context['message'] = "The password you entered is incorrect."
            # return render(request, 'signup.html', context)
            return render(request, 'signup.html', {'error': "비밀번호가 틀립니다."})
            
        elif username == '' or request.POST['Email'] == '' or request.POST['password'] == '' or request.POST['confirm'] == '':
            if username == '':
                return render(request, 'signup.html', {'error': "사용자 이름을 입력하세요."})
            elif request.POST['password'] == '':
                return render(request, 'signup.html', {'error': "비밀번호를 입력하세요."})
            elif request.POST['confirm'] == '':
                return render(request, 'signup.html', {'error': "비밀번호 확인을 입력하세요."})
            elif request.POST['Email'] == '':
                return render(request, 'signup.html', {'error': "이메일을 입력하세요."})
        
    # signup으로 GET 요청이 왔을 때, 회원가입 화면을 띄워준다.
    return render(request, 'signup.html')

# 로그인
def login(request):
    context = {}
    # login으로 POST 요청이 들어왔을 때, 로그인 절차를 밟는다.
    if request.method == 'POST':
        # login.html에서 넘어온 username과 password를 각 변수에 저장한다.
        username = request.POST['username']
        password = request.POST['password']

        # 해당 username과 password와 일치하는 user 객체를 가져온다.
        user = auth.authenticate(request, username=username, password=password)
        
        # 해당 user 객체가 존재한다면
        if user is not None:
            # 로그인 한다
            auth.login(request, user)
            return redirect('/')
        # 존재하지 않는다면
        else:
            # context['message'] = "로그인 정보가 맞지않습니다.\\n\\n확인하신 후 다시 시도해 주십시오."
            # 딕셔너리에 에러메세지를 전달하고 다시 login.html 화면으로 돌아간다.
            # return render(request, 'login.html', {'error' : 'username or password is incorrect.'})
            # return render(request, 'login.html', context)
            return render(request, 'login.html', {'error': "로그인 정보가 맞지않습니다.\n확인하신 후 다시 시도해 주십시오."})
    # login으로 GET 요청이 들어왔을때, 로그인 화면을 띄워준다.
    else:
        return render(request, 'login.html')

# 로그 아웃
def logout(request):
    # logout으로 POST 요청이 들어왔을 때, 로그아웃 절차를 밟는다.
    if request.method == 'POST':
        auth.logout(request)
        request.session.flush()
        return redirect('/')

    # logout으로 GET 요청이 들어왔을 때, 로그인 화면을 띄워준다.
    return render(request, 'login.html')