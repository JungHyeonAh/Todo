from django.shortcuts import render
from django.http import JsonResponse
from .oai_queries import get_completion, sum_text, sum_mp3, preset_all
from .forms import FileUploadForm
import os
from openai.error import InvalidRequestError

from base_preset.models import Preset
from django.views.generic.list import ListView

messages = []
conversation_id = None # gpt 대화 id

# 메인 페이지
def main_page(request):
    # if request.method == 'GET':
    preset_object = Preset.objects.all()
    return render(request, 'query.html', {'preset_object' : preset_object})

# ---------------------------------------------------------------------------------------------------------------------------------------
def query_view(request):
    global messages, conversation_id
    if request.method == 'POST':
        print(request)
        prompt = request.POST.get('prompt')
        response = get_completion(prompt, messages)
        # response, conversation_id = get_completion(prompt, messages, conversation_id)
        print(messages)
        return JsonResponse({'response': response})
    preset_object = Preset.objects.all()
    return render(request, 'query.html', {'preset_object' : preset_object})
    # return render(request, 'query.html')
# ---------------------------------------------------------------------------------------------------------------------------------------
def upload_all(request):
    global messages, conversation_id
    if request.method == 'POST':
        print(request)
        uploaded_file = request.FILES['file']
        file_ext = os.path.splitext(uploaded_file.name)[1]  # 파일 확장자 추출
        if file_ext == '.txt':
            # .txt 파일 업로드 처리
            prompt = uploaded_file.read().decode('utf-8')
            try:
                response = sum_text(prompt, messages)
                print(messages)
                return JsonResponse({'response': response})
            except InvalidRequestError as e:
                # 예외 처리 코드
                # messages = messages[-2:]
                messages = messages[-1:]
                # response = sum_text_t(messages) # 예외 처리 test
                response = sum_text(prompt, messages, None, 1)
                print(messages)
                return JsonResponse({'response': response})
                # return JsonResponse({'response': response, 'error_message': str(e)})
                # return render(request, 'query.html', {'error_message': str(e)})
        
        elif file_ext == '.mp3' or file_ext == '.m4a':
            try:
                response = sum_mp3(uploaded_file, messages, 0)
                print(messages)
                return JsonResponse({'response': response})
            except InvalidRequestError as e:
                # 예외 처리 코드
                # messages = messages[-2:]
                messages = messages[-1:]
                # response = sum_mp3_t(messages, 0) # 예외 처리 test
                response = sum_mp3(uploaded_file, messages, 0, 1)
                print(messages)
                return JsonResponse({'response': response})
                # return JsonResponse({'response': response, 'error_message': str(e)})
                # return render(request, 'query.html', {'error_message': str(e)})
    
    return render(request, 'query.html')
# ---------------------------------------------------------------------------------------------------------------------------------------
def presets(request):
    # global messages
    print(request)
    if request.method == 'POST':  
        texts = request.POST.get('text')
        print(texts)
        response = preset_all(messages, texts)
        return JsonResponse({'response': response})
    return render(request, 'query.html')
# ---------------------------------------------------------------------------------------------------------------------------------------
# class p_list(ListView):
# def p_list(request):
#     print(request)
#     if request.method == 'GET':
#     # model = Preset
#         preset_object = Preset.objects.all()
#     return render(request, 'query.html', {'preset_object' : preset_object})
# ---------------------------------------------------------------------------------------------------------------------------------------
