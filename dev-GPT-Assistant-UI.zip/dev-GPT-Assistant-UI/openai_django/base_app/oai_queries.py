# import settings
from django.conf import settings
import os
import openai
# from openai.error import InvalidRequestError

# OpenAI API Key
if settings.OPENAI_API_KEY:
    openai.api_key = settings.OPENAI_API_KEY
else:
    raise Exception('OpenAI API Key not found')

# conversation_id = None # gpt 대화 id

def get_completion(prompt, msg):    
    msg.append(
        {"role": "user", "content": prompt},
    )
        # cnt += 1
    query = openai.ChatCompletion.create(
        model='gpt-3.5-turbo',
        # messages=[{"role": "user", "content": prompt }]
        messages=msg
    )
    response = query.get('choices')[0]['message']['content']
    return response

# def get_completion(prompt, msg, conversation_id=None):    
#     # 이전 대화에서 생성된 대화 ID가 있는 경우
#     if conversation_id:
#         msg.append({"role": "assistant", "content": conversation_id})
        
#     # 사용자의 입력 추가
#     msg.append({"role": "user", "content": prompt})
    
#     # 대화 이어 나가기
#     text = openai.ChatCompletion.create(
#         model="gpt-3.5-turbo",
#         messages=msg
#     )
    
#     if len(msg) > 1:
#         msg.pop()
#     # msg.pop()
#     response = text.get('choices')[0]['message']['content']
#     conversation_id = text.id
    
#     return response, conversation_id

# ---------------------------------------------------------------------------------------------------------------------------------------
def sum_text(prompt, msg, conversation_id=None, error=0):
    if error != 0:
        text = openai.ChatCompletion.create(
            model='gpt-3.5-turbo',
            messages=msg
        )
        
        response = text.get('choices')[0]['message']['content']
        return response

    else:
        prompt += "'회의 시간: , 회의 장소: , 미팅 목적: , 참석자: , 주요내용: , 결론: '으로 요약해줘."
        
        msg.append(
            {"role": "user", "content": prompt},
        )
        text = openai.ChatCompletion.create(
            model='gpt-3.5-turbo',
            messages=msg
        )
        
        response = text.get('choices')[0]['message']['content']
        return response

# ---------------------------------------------------------------------------------------------------------------------------------------
def sum_mp3(mp3_file, msg, opt, error=0):
    # prompt += "'회의 시간: , 회의 장소: , 미팅 목적: , 참석자: , 주요내용: , 결론: '으로 요약해줘."
    # prompt += "Summarize into Date: , Important Word: , Summary: ."
    if error != 0:
        if opt == 0:
            text = openai.ChatCompletion.create(
                model='gpt-3.5-turbo',
                messages=msg
            )
            response = text.get('choices')[0]['message']['content']
            return response
    else:
        if opt == 0:
            transcript = openai.Audio.transcribe("whisper-1", mp3_file)
            texts = transcript['text']
            texts += "'회의 시간: , 회의 장소: , 미팅 목적: , 참석자: , 주요내용: , 결론: '으로 요약해줘."
            msg.append(
                {"role": "user", "content": texts},
            )
            text = openai.ChatCompletion.create(
                model='gpt-3.5-turbo',
                messages=msg
            )
            response = text.get('choices')[0]['message']['content']
            return response
    
# ---------------------------------------------------------------------------------------------------------------------------------------


# ---------------------------------------------------------------------------------------------------------------------------------------
# preset
def preset_all(msg, texts):
    msg.append(
        {"role": "user", "content": texts},
    )
    text = openai.ChatCompletion.create(
        model='gpt-3.5-turbo',
        messages=msg
    )
    response = text.get('choices')[0]['message']['content']
    return response

# ---------------------------------------------------------------------------------------------------------------------------------------