from django.db import models

# Create your models here.
class Preset(models.Model):
    preset_btn_name = models.CharField(max_length=100)
    # preset_data_text = models.CharField(max_length=100)
    preset_data_text = models.TextField()
    
    def __str__(self):
        # 객체를 출력할 때 나타나는 값
        return "이름 : " + self.preset_btn_name + ", 텍스트 : " + self.preset_data_text