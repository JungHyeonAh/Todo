from django.urls import path
from .views import *

urlpatterns = [
    path('', PresetListView.as_view(), name='list'),
    path('add/',PresetCreateView.as_view(), name='add'),
    path('detail/<int:pk>/',PresetDetailView.as_view(), name='detail'),
    path('update/<int:pk>/', PresetUpdateView.as_view(), name='update'),
    path('delete/<int:pk>/', PresetDeleteView.as_view(), name='delete'),
]