from django.contrib import admin
from .models import Preset

# Register your models here.
admin.site.register(Preset)