from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic.detail import DetailView
from django.urls import reverse_lazy
from .models import Preset

# Create your views here.
class PresetListView(ListView):
    model = Preset

##Create Preset 메서드 추가
class PresetCreateView(CreateView):
    model = Preset
    fields = ['preset_btn_name', 'preset_data_text']
    success_url = reverse_lazy('list')                   # reverse_lazy -> class 내부에서 변수로 url 반환 값을 선언하고자 할 때 사용
    template_name_suffix = '_create'
    
##View Detail Preset 메서드 추가
class PresetDetailView(DetailView):
    model = Preset
    
##Update View Preset 메서드 추가
class PresetUpdateView(UpdateView):
    model = Preset
    fields = ['preset_btn_name', 'preset_data_text']
    success_url = reverse_lazy('list')
    template_name_suffix = '_update'
    
##Delete View Preset 메서드 추가
class PresetDeleteView(DeleteView):
    model = Preset
    success_url = reverse_lazy('list')
    template_name_suffix = '_confirm_delete'